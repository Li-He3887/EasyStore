$(document).foundation();
console.log('testing123')


$(".testtest").on('init', function() {
    console.log("onInit");
    $(".testtest").slick();
});

$(".testtest").on('reInit', function() {
    console.log("onReInit");
    $(".testtest").slick("slickGoTo",0);
});

$(".testtest").slick({
    infinite: true,
    slidesToScroll: 3,
    slidesToShow: 3,
    centerPadding: "20px",
    draggable:true
});


