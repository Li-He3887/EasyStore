import React from 'react'

const NotFound = () => {
  return (
    <>
      <h1 style={{color:"red",textAlign:"center",lineHeight:"10"}}>No se encuentra ruta</h1>
    </>
  )
}

export default NotFound
